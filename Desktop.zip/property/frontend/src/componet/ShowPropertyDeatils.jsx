// ShowPropertyDetail.jsx
import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Card, Button } from 'react-bootstrap';
import axios from 'axios';

const ShowPropertyDetail = () => {
  const [properties, setProperties] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('http://localhost:3000/api/properties');
        if (response.data.result === 1) {
          setProperties(response.data.data.properties || []);
        } else {
          console.error('Failed to fetch properties:', response.data.msg);
        }
      } catch (error) {
        console.error('Error:', error.message);
      }
    };

    fetchData();
  }, []);

  return (
    <Container className="mt-4">
      <h2 className="text-center mb-4">Properties</h2>
      <Row xs={1} md={2} lg={3} className="g-4">
        {properties.map((property) => (
          <Col key={property._id} className="mb-3">
            <Card>
            <Card.Img
  variant="top"
  src={`http://localhost:3000/${property.imagePaths && property.imagePaths[0]}`}
  alt="Property"
/>



              <Card.Body>
                <Card.Title>{property.name}</Card.Title>
                <Card.Text>
                  <strong>Address:</strong> {property.address?.street || 'N/A'} <br />
                  <strong>Type:</strong> {property.type || 'N/A'} <br />
                  <strong>Owner's Name:</strong> {property.owner?.firstName} {property.owner?.lastName} <br />
                  <strong>Units:</strong> {property.units || 0} <br />
                  <strong>Size:</strong> {property.size || 0} sqft <br />
                  <strong>Rent:</strong> ${property.rent || 0}
                </Card.Text>
                <Button variant="primary" className="me-2">
                  Edit
                </Button>
                <Button variant="danger">
                  Delete
                </Button>
              </Card.Body>
            </Card>
          </Col>
        ))}
      </Row>
    </Container>
  );
};

export default ShowPropertyDetail;
