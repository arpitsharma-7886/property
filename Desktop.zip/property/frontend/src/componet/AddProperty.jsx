import React, { useState } from 'react';
import { Form, Button, Container, Row, Col } from 'react-bootstrap';
import axios from 'axios';

const AddPropertyForm = () => {
  const [formData, setFormData] = useState({
    name: '',
    address: {
      street: '',
      city: '',
      state: '',
      zipCode: '',
    },
    type: '',
    owner: {
      firstName: '',
      lastName: '',
      contactNumber: '',
      email: '',
    },
    units: 0,
    size: 0,
    rent: 0,
    images: [],
  });

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleAddressChange = (e) => {
    const { name, value } = e.target;

    setFormData((prevData) => ({
      ...prevData,
      address: {
        ...prevData.address,
        [name]: value,
      },
    }));
  };

  const handleOwnerChange = (e) => {
    const { name, value } = e.target;

    setFormData((prevData) => ({
      ...prevData,
      owner: {
        ...prevData.owner,
        [name]: value,
      },
    }));
  };

  const handleImageChange = (e) => {
    const files = Array.from(e.target.files);

    setFormData((prevData) => ({
      ...prevData,
      images: [...prevData.images, ...files],
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
  
    try {
      const formDataToSend = new FormData();
  
      formDataToSend.append('name', formData.name);
      formDataToSend.append('address', JSON.stringify(formData.address));
      formDataToSend.append('type', formData.type);
      formDataToSend.append('owner', JSON.stringify(formData.owner));
      formDataToSend.append('units', formData.units);
      formDataToSend.append('size', formData.size);
      formDataToSend.append('rent', formData.rent);
  
      formData.images.forEach((image, index) => {
        formDataToSend.append('images', image);
      });
  
      const response = await axios.post('http://localhost:3000/api/properties', formDataToSend);
  
      if (response.data.result === 1) {
        console.log('Property added successfully:', response.data.data.property);
        // You can redirect, show a success message, etc. based on your application's logic
      } else {
        console.error('Failed to add property:', response.data.msg);
        // Handle error, show error message, etc.
      }
    } catch (error) {
      console.error('Error:', error.message);
      // Handle error, show error message, etc.
    }
  };
  
    return (
        <Container>
            <Row className="justify-content-md-center">
                <Col xs={12} md={8}>
                    <Form onSubmit={handleSubmit}>
                        {/* Name */}
                        <Form.Group controlId="formName">
                            <Form.Label>Name:</Form.Label>
                            <Form.Control type="text" name="name" value={formData.name} onChange={handleChange} />
                        </Form.Group>

                        {/* Address */}
                        <Form.Group controlId="formStreet">
                            <Form.Label>Street:</Form.Label>
                            <Form.Control type="text" name="street" value={formData.address.street} onChange={handleAddressChange} />
                        </Form.Group>
                        <Form.Group controlId="formCity">
                            <Form.Label>City:</Form.Label>
                            <Form.Control type="text" name="city" value={formData.address.city} onChange={handleAddressChange} />
                        </Form.Group>
                        <Form.Group controlId="formState">
                            <Form.Label>State:</Form.Label>
                            <Form.Control type="text" name="state" value={formData.address.state} onChange={handleAddressChange} />
                        </Form.Group>
                        <Form.Group controlId="formZipCode">
                            <Form.Label>Zip Code:</Form.Label>
                            <Form.Control type="text" name="zipCode" value={formData.address.zipCode} onChange={handleAddressChange} />
                        </Form.Group>

                        <Form.Group controlId="formType">
                            <Form.Label>Type:</Form.Label>
                            <Form.Control as="select" name="type" value={formData.type} onChange={handleChange}>
                                <option value="" disabled>Select property type</option>
                                <option value="Residential">Residential</option>
                                <option value="Commercial">Commercial</option>
                            </Form.Control>
                        </Form.Group>

                        {/* Owner */}
                        <Form.Group controlId="formFirstName">
                            <Form.Label>First Name:</Form.Label>
                            <Form.Control type="text" name="firstName" value={formData.owner.firstName} onChange={handleOwnerChange} />
                        </Form.Group>
                        <Form.Group controlId="formLastName">
                            <Form.Label>Last Name:</Form.Label>
                            <Form.Control type="text" name="lastName" value={formData.owner.lastName} onChange={handleOwnerChange} />
                        </Form.Group>
                        <Form.Group controlId="formContactNumber">
                            <Form.Label>Contact Number:</Form.Label>
                            <Form.Control type="text" name="contactNumber" value={formData.owner.contactNumber} onChange={handleOwnerChange} />
                        </Form.Group>
                        <Form.Group controlId="formEmail">
                            <Form.Label>Email:</Form.Label>
                            <Form.Control type="text" name="email" value={formData.owner.email} onChange={handleOwnerChange} />
                        </Form.Group>

                        {/* Units */}
                        <Form.Group controlId="formUnits">
                            <Form.Label>Units:</Form.Label>
                            <Form.Control type="number" name="units" value={formData.units} onChange={handleChange} />
                        </Form.Group>

                        {/* Size */}
                        <Form.Group controlId="formSize">
                            <Form.Label>Size:</Form.Label>
                            <Form.Control type="number" name="size" value={formData.size} onChange={handleChange} />
                        </Form.Group>

                        {/* Rent */}
                        <Form.Group controlId="formRent">
                            <Form.Label>Rent:</Form.Label>
                            <Form.Control type="number" name="rent" value={formData.rent} onChange={handleChange} />
                        </Form.Group>

                        {/* Images */}
                        <Form.Group controlId="formImages">
                            <Form.Label>Images:</Form.Label>
                            <Form.Control type="file" name="images" onChange={handleImageChange} multiple accept="image/*" />
                            
                        </Form.Group>

                        {/* Submit Button */}
                        <Button variant="primary" type="submit">
                            Submit
                        </Button>
                    </Form>
                </Col>
            </Row>
        </Container>
    );
};

export default AddPropertyForm;
