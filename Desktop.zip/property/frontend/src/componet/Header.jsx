// PropertyManagement.js
import React from 'react';
import { Link } from 'react-router-dom';

const Header = () => {
  return (
    <div>
      <h1 className="text-center">Property Management</h1>
      <header className="d-flex justify-content-center py-3">
        <ul className="nav nav-pills">
          <li className="nav-item">
            <Link to="/addproperty" className="nav-link active">
              Add Property
            </Link>
          </li>

          <li className="nav-item mx-3">
            <Link to="/showproperty" className="nav-link active">
              Show Property
            </Link>
          </li>
        </ul>
        
      </header>
    </div>
  );
};

export default Header;
