import { useState } from 'react'
import "bootstrap/dist/css/bootstrap.min.css"
import Header from './componet/header'
import AddPropertyForm from './componet/AddProperty';
import { Route, Routes } from 'react-router-dom';
import ShowPropertyDetail from './componet/ShowPropertyDeatils';

function App() {

  return (
    
   <>
   <Routes>
    <Route path="/" element={<Header/>} />
    <Route path="/addproperty" element={<AddPropertyForm />} />
    <Route path="/showproperty" element={<ShowPropertyDetail />} />
   </Routes>
   </>
  
  )
}

export default App
