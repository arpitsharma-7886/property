const express = require("express");
const app = express();
require('dotenv').config();

const path = require("path"); 
const propertyRoutes = require('./routes/propertyRoutes')
const PORT = process.env.PORT || 3000;
// contect db
const {connectToMongoDB} = require('./middleware/db');
connectToMongoDB();
const cors = require('cors');
// Enable CORS for all routes
app.use(cors());
// Middleware to parse JSON requests
app.use(express.json());
// for api routes
app.use('/api',propertyRoutes);
// Middleware to handle URL-encoded data
app.use(express.urlencoded({ extended: true }));
// Middleware to serve static files  like uploads
app.use("/uploads", express.static(path.join(__dirname, "uploads")));  // Upd
// Middleware to handle CORS (Cross-Origin Resource Sharing)
app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

app.use('/api/',propertyRoutes)

app.listen(PORT, () => {
    console.log("Server is running on port " + PORT);
});
