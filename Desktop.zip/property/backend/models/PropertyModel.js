const mongoose = require('mongoose');

const propertySchema = new mongoose.Schema({
    name: {
        type: String,
    },
    address: {
        street: String,
        city: String,
        state: String,
        zipCode: String,
    },
    type: {
        type: String,
        enum: ['Residential', 'Commercial']
    },
    owner: {
        firstName: String,
        lastName: String,
        contactNumber: String,
        email: String,
    },
    units: Number,
    size: Number,
    rent: Number,
    imagePaths: [String],
});

const PropertyModel = mongoose.model('Property', propertySchema);

module.exports = PropertyModel;
