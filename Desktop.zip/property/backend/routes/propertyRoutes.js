const express = require('express');
const router = express.Router();
const multer = require('multer');
const PropertyController = require('../controllers/PropertyController');

// Multer configuration for handling file uploads
const multerConfig = {
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
      cb(null, Date.now() + '-' + file.originalname);
    },
  }),
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type'), false);
    }
  },
};

const upload = multer(multerConfig).array('images', 5);

router.get('/properties', PropertyController.getAllProperties);
router.get('/properties/:id', PropertyController.getPropertyById);

// Attach the multer middleware before the route handler
router.post('/properties', (req, res, next) => {
    // Use Multer middleware and handle the result in the next middleware
    upload(req, res, (err) => {
      if (err) {
        return res.status(400).json({ error: err.message });
      }
  
      // Access the file paths from req.files
      const imagePaths = req.files?.map((file) => file.path);
  
      // Attach the image paths to the response
      req.imagePaths = imagePaths;
      next();
    });
  }, PropertyController.addProperty);
router.put('/properties/:id', (req, res, next) => {
    // Use Multer middleware and handle the result in the next middleware
    upload(req, res, (err) => {
      if (err) {
        return res.status(400).json({ error: err.message });
      }
  
      // Access the file paths from req.files
      const imagePaths = req.files.map((file) => file.path);
  
      // Attach the image paths to the response
      req.imagePaths = imagePaths;
      next();
    });
  }, PropertyController.updateProperty);
router.delete('/properties/:id', PropertyController.deleteProperty);

module.exports = router;
