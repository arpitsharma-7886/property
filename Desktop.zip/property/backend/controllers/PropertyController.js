const Property = require('../models/PropertyModel');
const multer = require('multer');
const upload = multer({ dest: 'uploads/' });
class PropertyController {
    static async getAllProperties(req, res) {
        try {
            const properties = await Property.find();
            return res.json({ result: 1, msg: "Success", data: { properties } });
        } catch (error) {
            console.error("Error fetching properties:", error);
            return res.status(500).json({ result: -1, msg: "Internal server error", data: null });
        }
    }

    static async getPropertyById(req, res) {
        const propertyId = req.params.id;
        try {
            const property = await Property.findById(propertyId);
            if (!property) {
                return res.status(404).json({ result: -1, msg: "Property not found", data: null });
            }
            return res.json({ result: 1, msg: "Success", data: { property } });
        } catch (error) {
            console.error("Error fetching property:", error);
            return res.status(500).json({ result: -1, msg: "Internal server error", data: null });
        }
    }

    static async addProperty(req, res) {
        // Handle multiple image uploads using Multer
        const imagePaths = req.files?.map((file) => file.path);
       console.log(imagePaths)
        // Extract other property data from the request body
        const propertyData = { ...req.body, imagePaths: imagePaths };

        try {
            const newProperty = new Property(propertyData);
            await newProperty.save();
            return res.json({ result: 1, msg: "Property added successfully", data: { property: newProperty } });
        } catch (error) {
            console.error("Error adding property:", error);
            return res.status(500).json({ result: -1, msg: "Internal server error", data: null });
        }
    }

    static async updateProperty(req, res) {
        const propertyId = req.params.id;

        // Handle multiple image uploads using Multer
        const imagePaths = req.files ? req.files.map(file => file.filename) : [];

        // Extract other property data from the request body
        const updatedData = { ...req.body, images: imagePaths };

        try {
            const updatedProperty = await Property.findByIdAndUpdate(propertyId, updatedData, { new: true });
            if (!updatedProperty) {
                return res.status(404).json({ result: -1, msg: "Property not found", data: null });
            }
            return res.json({ result: 1, msg: "Property updated successfully", data: { property: updatedProperty } });
        } catch (error) {
            console.error("Error updating property:", error);
            return res.status(500).json({ result: -1, msg: "Internal server error", data: null });
        }
    }
    static async deleteProperty(req, res) {
        const propertyId = req.params.id;
        try {
            const deletedProperty = await Property.findByIdAndDelete(propertyId);
            if (!deletedProperty) {
                return res.status(404).json({ result: -1, msg: "Property not found", data: null });
            }
            return res.json({ result: 1, msg: "Property deleted successfully", data: { property: deletedProperty } });
        } catch (error) {
            console.error("Error deleting property:", error);
            return res.status(500).json({ result: -1, msg: "Internal server error", data: null });
        }
    }
}

module.exports = PropertyController;
